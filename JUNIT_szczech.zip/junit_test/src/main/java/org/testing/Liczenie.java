package org.testing;

public class Liczenie {

    public int dodawanie(int a, int b) {
        return a + b;
    }

    public int odejmowanie(int a, int b) {
        return a - b;
    }

    public int mnozenie(int a, int b) {
        return a * b;
    }

    public int dzielenie(int a, int b) {
        if (a == 0 || b == 0)
        {throw new IllegalArgumentException("Nie dziel przez 0");}
        return a / b;
    }
}

