package org.testing;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LiczenieTest {

    @Test
    public void test1() {
        Liczenie liczenie = new Liczenie();
        int wynik = liczenie.dodawanie(2, 2);
        assertEquals(4, wynik);
    }

    @Test
    public void test2() {
        Liczenie liczenie = new Liczenie();
        int wynik = liczenie.odejmowanie(3, 2);
        assertEquals(1, wynik);
    }

    @Test
    public void test3() {
        Liczenie liczenie = new Liczenie();
        int wynik = liczenie.mnozenie(2, 5);
        assertEquals(10, wynik);
    }

    @Test
    public void test4() {
        Liczenie liczenie = new Liczenie();
        int wynik = liczenie.dzielenie(6, 3);
        assertEquals(2, wynik);
        assertThrows(IllegalArgumentException.class, () -> {liczenie.dzielenie(6, 0);});
        assertThrows(IllegalArgumentException.class, () -> {liczenie.dzielenie(0, 6);});
    }
}

